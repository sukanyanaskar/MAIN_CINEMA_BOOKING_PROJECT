<html>

<head>
    <title>Book Table Entry</title>
</head>

<body>
    <?php
     include 'connection.php';

                $userid=$_POST['userid'];
                $hall_location=$_POST['location'];
                $showTime=$_POST['time_ins'];


$sql = "INSERT INTO bookings (userid,hall_location,showTime) VALUES ('$userid', '$hall_location', '$showTime')";


if ($conn->query($sql) === TRUE) {
    echo'<script>alert("Time Preference Selected. Now select seat Preference");window.location.replace("booking2.php");</script>';
    
  
} else {
    echo "<script type='text/javascript'> { alert('Problem Allocating Time. Try Again.');} window.location.replace('booking.php');</script>";
            }


                $conn->close();
            // Check connection

            
        ?>
</body>

</html>





