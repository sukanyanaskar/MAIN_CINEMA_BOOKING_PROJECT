<html>

<head>
    <title>Seat Allocation</title>
</head>

<body>
    <?php
     include 'connection.php';

                $numSeats=$_POST['no_of_tickets'];


$sql = "INSERT INTO bookings (numSeats) VALUES ('$numSeats')";


if ($conn->query($sql) === TRUE) {
    echo'<script>alert("Seat Allocation Successful. Continue with the payment process :) ");window.location.replace("payment.php");</script>';
    
  
} else {
    echo "<script type='text/javascript'> { alert('Problem assigning seat. Try Again.');} window.location.replace('booking.php');</script>";
            }


                $conn->close();
            // Check connection

            
        ?>
</body>

</html>





