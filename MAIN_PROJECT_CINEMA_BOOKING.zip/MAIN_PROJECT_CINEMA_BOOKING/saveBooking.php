<?php
session_start();
if ( isset( $_SESSION['user_id'] ) ) {
    $idh=$_SESSION['user_id'];
    
} else {echo 'session expired.';
    header("Refresh:0; URL=expiredsess.php");
    die();
}

             $message="Booking Successful!!";

        echo"<script type='text/javascript'> { alert('$message');} window.location.replace('index_signedin.php');</script>";

?>
</body>

</html>
