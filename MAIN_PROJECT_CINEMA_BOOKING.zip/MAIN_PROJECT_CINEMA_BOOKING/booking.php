<!---------------------------------------------------------  HEADER -------------------------------------------------------------------->

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cinema Booking System For A Multiplex</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

<!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

<!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">
    <link href="css/cineworld.css" rel="stylesheet">
    <link href="css/booking.css" rel="stylesheet">

<!-- Footer CSS -->
    <link rel="stylesheet" href="footers/assets/css/Footer-with-map.css">
<!-- icon -->
    <link rel="shortcut icon" href="img/logo2.png" type="img/ico">

    <style>
        #invisible {
            display: none;
        }
    </style>
    <style>
        body {
    background:rgba(40,100,101,.9);
        }

      *{
        box-sizing: border-box;
      }
      .column {
    float: left;
    width: 33.33%;
    padding: 0px;
}
.row::after {
    content: "";
    clear: both;
    display: table;
}
.booking-html{
    width:100%;
    height:100%;
    position:absolute;
    padding:90px 70px 50px 70px;
}
.dropbtn {
  background-color: #010101;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
.timings {
    height: 40px;
    background-color: rgba(100, 100, 100, 0.4);
    margin-top: 10px;
    margin-bottom: 10px;
}
.date {
    font-family: Arial;
    color: silver;
}
.btn1 {
    margin-top: 7px;
    margin-left: 10px;
    font-family: eras itc;
    background-color: rgba(150, 100, 125, 0.2);
    border: 1px solid;
    border-radius: 5px;
    height: 26px;
    width: 80px;
    color: white;
    cursor: pointer;
    box-shadow: 0 4px rgba(0, 0, 0, 0.7);
}

.btn1:hover {
    background-color: rgba(0, 0, 0, 0.3);
}

.btn1:active {
    background-color: rgba(0, 0, 0, 0.1);
    box-shadow: 0 5px rgba(57, 255, 0, 1);
    transform: translateY(1px);
}

.btnq:hover {
    background-color: rgba(0, 0, 0, 0.3);
}

.btnq:active {
    background-color: rgba(0, 0, 0, 0.3);
    box-shadow: 0 5px rgba(57, 255, 0, 1);
    ;
    transform: translateY(1px);
}

.btnq {
    cursor: pointer;
    box-shadow: 0 4px rgba(0, 0, 0, 0.7);
    color: white;
    margin-top: 7px;
    margin-left: 100px;
    font-family: eras itc;
    background-color: rgba(150, 100, 125, 0.2);
    border: 1px solid;
    border-radius: 5px;
    height: 26px;
}

.locq {
    cursor: pointer;
    box-shadow: 0 4px rgba(0, 0, 0, 0.7);
    color: white;
    margin-top: 7px;
    margin-left: 148px;
    font-family: eras itc;
    background-color: rgba(150, 100, 125, 0.2);
    border: 1px solid;
    border-radius: 5px;
    height: 26px;
    width: 100px;
}

.input {
    box-shadow: 0 4px rgba(0, 0, 0, 0.7);
    color: white;
    margin-top: 7px;
    margin-left: 182px;
    font-family: eras itc;
    background-color: rgba(150, 100, 125, 0.2);
    border: 1px solid;
    border-radius: 5px;
    height: 26px;
    width: 400px;
}



.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>


</head>

<body>

<!-- Navigation -->
<div class="booking-html">
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index_signedin.php"><span><img src="img/cin_icon.jpeg" height="35px"></span></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="navbar-collapse-1">
                <ul class="nav navbar-nav" id="left-nav">
                    <li>
                        <div class="dropdown">
                          </q><button class="dropbtn">LANGUAGE</button>
                            <div class="dropdown-content">
                            <a href="Hindi.php">HINDI</a>
                              <a href="English.php">ENGLISH</a>
                              <a href="Bengali.php">BENGALI</a>
                            </div>
                            </div>
                    </li>
                    <li>
                        <div class="dropdown">
                          </q><button class="dropbtn">LOCATION</button>
                            <div class="dropdown-content">
                            <a href="Kolkata.php">KOLKATA</a>
                            </div>
                            </div>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="faq.php"><span class="fa fa-question-circle" aria-hidden="true"></span>&nbsp;&nbsp;SUPPORT</a>
                    </li>
                    <li>
                        <a href="contact.php"><span class="fa fa-phone" aria-hidden="true"></span>&nbsp;&nbsp;CONTACT</a>
                    </li>
                    <li>
                        <a href="index.php">&nbsp;&nbsp;LOG OUT</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

<!---------------------------------------------------------  HEADER  ENDED  ----------------------------------------------------------> 

<!-- Content Row -->

 <!-- BookMovie Form -->

    <div class="container">
        </br>
        </br>
    <form  action="book1.php"  method="post">

        <div class="timings">
        <div class="group">
            <label class="date">Email ID</label>
            <input name="userid" id="user" type="text" class="input">

        </div>
    </div>

     <div class="timings">
            <label class="date">Hall Location</label>
            <input class="locq" type="text" name="location" value="Kolkata">

    </div>

    <div style="margin-left:500px; color:white">
    </br>
        <h3><b>TIME PREFERRENCE</b></h3>
    </br>
    </div>
        
        <div class="timings">

            <label class="date">5th November 2019</label>
            <button class="btnq" name="time_ins" value="10:30"><span>10:30 am </span></button>
            <button class="btn1" name="time_ins" value="01:15"><span>01:15 pm </span></button>
            <button class="btn1" name="time_ins" value="04:30"><span>04:30 pm </span></button>
            <button class="btn1" name="time_ins" value="07:00"><span>07:00 pm </span></button>
        </div>
        <div class="timings">
            <label class="date">6th November 2019</label>
            <button class="btnq" name="time_ins" value="10:30"><span>10:30 am </span></button>
            <button class="btn1" name="time_ins" value="01:15"><span>01:15 pm </span></button>

        </div>
        <div class="timings">
            <label class="date">7th November 2019</label>
            <button class="btnq" name="time_ins" value="04:30"><span>04:30 pm </span></button>
            <button class="btn1" name="time_ins" value="07:00"><span>07:00 pm </span></button>
        </div>
        <div class="timings">
            <label class="date">8th November 2019</label>

            <button class="btnq" name="time_ins" value="01:15"><span>01:15 pm </span></button>


        </div>

<br><br><br><br>

   </div>
</div>
  

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.3.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="js/jqBootstrapValidation.js"></script>
<script src="js/booking.js"></script>


</body>

</html>




