
<!---------------------------------------------------------  HEADER -------------------------------------------------------------------->

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cinema Booking System For A Multiplex</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

<!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

<!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">
    <link href="css/cineworld.css" rel="stylesheet">

<!-- Footer CSS -->
    <link rel="stylesheet" href="footers/assets/css/Footer-with-map.css">
<!-- icon -->
    <link rel="shortcut icon" href="img/logo2.png" type="img/ico">

    <style>
        #invisible {
            display: none;
        }
    </style>
    <style>
      *{
        box-sizing: border-box;
      }
      .column {
    float: left;
    width: 33.33%;
    padding: 0px;
}
.row::after {
    content: "";
    clear: both;
    display: table;
}
.dropbtn {
  background-color: #010101;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>


</head>

<body>

<!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index_signedin.php"><span><img src="img/cin_icon.jpeg" height="35px"></span></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="navbar-collapse-1">
                <ul class="nav navbar-nav" id="left-nav">
                    <li>
                        <div class="dropdown">
                          </q><button class="dropbtn">LANGUAGE</button>
                            <div class="dropdown-content">
                            <a href="Hindi.php">HINDI</a>
                              <a href="English.php">ENGLISH</a>
                              <a href="Bengali.php">BENGALI</a>
                            </div>
                            </div>
                    </li>
                    <li>
                        <div class="dropdown">
                          </q><button class="dropbtn">LOCATION</button>
                            <div class="dropdown-content">
                            <a href="Kolkata.php">KOLKATA</a>
                            </div>
                            </div>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="faq.php"><span class="fa fa-question-circle" aria-hidden="true"></span>&nbsp;&nbsp;SUPPORT</a>
                    </li>
                    <li>
                        <a href="contact.php"><span class="fa fa-phone" aria-hidden="true"></span>&nbsp;&nbsp;CONTACT</a>
                    </li>
                    <li>
                        <a href="index.php">&nbsp;&nbsp;LOG OUT</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
      </br>
    <div class="row">
      <div class="column">
        <img src="img/black.jpeg" height="100px" style="width:100%">
      </div>
      <div class="column">
        <img src="img/cin_logo.png" height="100px" style="width:100%">
      </div>
      <div class="column">
        <img src="img/black.jpeg" height="100px" style="width:100%">
      </div>
    </div>
  </div>

<!---------------------------------------------------------  HEADER  ENDED  ----------------------------------------------------------> 


  <div class="container">
   </br>
</br>
</br>      <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <div id="carousel1" class="carousel slide">
          <ol class="carousel-indicators">
            <li data-target="#carousel1" data-slide-to="0" class="active"> </li>
            <li data-target="#carousel1" data-slide-to="1" class=""> </li>
            <li data-target="#carousel1" data-slide-to="2" class=""> </li>
            <li data-target="#carousel1" data-slide-to="3" class=""> </li>
          </ol>
          <div class="carousel-inner">
            <div class="item active"> <img class="img-responsive" src="img/1.jpg" alt="thumb">
              <div class="carousel-caption"><b>Looper</b> </div>
            </div>
            <div class="item"> <img class="img-responsive" src="img/1.jpg" alt="thumb">
              <div class="carousel-caption"><b>Magic The Gathering</b></div>
            </div>
            <div class="item"> <img class="img-responsive" src="img/1.jpg" alt="thumb">
              <div class="carousel-caption"><b>The Amazing Spider Man 2</b></div>
            </div>
            <div class="item"> <img class="img-responsive" src="img/1.jpg" alt="thumb">
              <div class="carousel-caption"><b>The Blacklist Redemption</b></div>
            </div>
          </div>
          <a class="left carousel-control" href="#carousel1" data-slide="prev"><span class="icon-prev"></span></a> <a class="right carousel-control" href="#carousel1" data-slide="next"><span class="icon-next"></span></a></div>
      </div>
</div>
    <br>
</div>

<!---  Movies that are currently running -->

<h2 class="text-center">NOW SHOWING</h2>
</br>
</br>
<div class="container">
</br>
  <div class="row text-center">

    <div class="col-lg-4 col-xs-6 col-sm-3 col-md-3">
      <div class="thumbnail"> <img src="img/1.jpg" alt="Thumbnail Image 1" class="img-responsive">
        <div class="caption">
          <h3>Movie 1</h3>
            <p><a href="1.php" class="btn btn-primary" role="button"><span aria-hidden="true"></span> Book Now</a> </p>
        </div>
      </div>
    </div>

   <div class="col-lg-4 col-xs-6 col-sm-3 col-md-3">
      <div class="thumbnail"> <img src="img/1.jpg" alt="Thumbnail Image 1" class="img-responsive">
        <div class="caption">
          <h3>Movie2</h3>
          <p><a href="2.php" class="btn btn-primary" role="button"><span aria-hidden="true"></span> Book Now</a> </p>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-xs-6 col-sm-3 col-md-3">
      <div class="thumbnail"> <img src="img/1.jpg" alt="Thumbnail Image 1" class="img-responsive">
        <div class="caption">
          <h3>Movie 3</h3>
          <p><a href="3.php" class="btn btn-primary" role="button"><span aria-hidden="true"></span> Book Now</a> </p>
        </div>
      </div>
    </div>

      <div class="col-lg-4 col-xs-6 col-sm-3 col-md-3">
      <div class="thumbnail"> <img src="img/1.jpg" alt="Thumbnail Image 1" class="img-responsive">
        <div class="caption">
          <h3>Movie 4</h3>
         <p><a href="4.php" class="btn btn-primary" role="button"><span aria-hidden="true"></span> Book Now</a> </p>
        </div>
      </div>
    </div>

   <div class="col-lg-4 col-xs-6 col-sm-3 col-md-3">
      <div class="thumbnail"> <img src="img/1.jpg" alt="Thumbnail Image 1" class="img-responsive">
        <div class="caption">
          <h3>Movie 5</h3>
          <p><a href="5.php" class="btn btn-primary" role="button"><span aria-hidden="true"></span> Book Now</a> </p>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-xs-6 col-sm-3 col-md-3">
      <div class="thumbnail"> <img src="img/1.jpg" alt="Thumbnail Image 1" class="img-responsive">
        <div class="caption">
          <h3>Movie 6</h3>
          <p><a href="6.php" class="btn btn-primary" role="button"><span aria-hidden="true"></span> Book Now</a> </p>
        </div>
      </div>
    </div>

<!--- Movies that are coming up soon -->

</div>
<br>
<h2 class="text-center">COMING SOON</h2>
<br>
<br>
<div class="container">
  <div class="row">
    <div class="col-lg-4 col-md-6">
      <div class="media-object-default">
        <div class="media">
          <div class="media-left"> <a href="#"> <img class="media-object" src="img/10.jpg" alt="placeholder image"> </a> </div>
          <div class="media-body">
            <h4 class="media-heading">Movie 1</h4>
            Releasing On 
            Friday,
            March 1 </div>
        </div>
        <div class="media">
          <div class="media-left"> <a href="#"> <img class="media-object" src="img/11.jpg" alt="placeholder image"> </a> </div>
          <div class="media-body">
             <h4 class="media-heading">Movie 2</h4>
            Releasing On 
            Saturday,
            March 2 </div>
        </div>
      </div>
    </div>
    <hr class="hidden-md hidden-lg">
    <div class="col-lg-4 col-md-6">
      <div class="media-object-default">
        <div class="media">
          <div class="media-left"> <a href="#"> <img class="media-object" src="img/13.jpg" alt="placeholder image"></a></div>
          <div class="media-body">
             <h4 class="media-heading">Movie 4</h4>
            Releasing On 
            Monday,
            March 4 </div>
        </div>
        <div class="media">
          <div class="media-left"> <a href="#"> <img class="media-object" src="img/14.jpg" alt="placeholder image"></a></div>
          <div class="media-body">
             <h4 class="media-heading">Movie 5</h4>
            Releasing On 
            Thuesday,
            March 5 </div>
        </div>
      </div>
    </div>
    <hr class="hidden-lg">
    <div class="col-lg-4 col-md-12 hidden-md">
      <div class="media-object-default">
        <div class="media">
          <div class="media-left"> <a href="#"> <img class="media-object" src="img/16.jpg" alt="placeholder image"></a></div>
          <div class="media-body">
             <h4 class="media-heading">Movie 6</h4>
            Releasing On 
            Thursday,
            March 7 </div>
        </div>
        <div class="media">
          <div class="media-left"> <a href="#"> <img class="media-object" src="img/17.jpg" alt="placeholder image"></a></div>
          <div class="media-body">
           <h4 class="media-heading">Movie 7</h4>
            Releasing On 
            Friday,
            March 8 </div>
        </div>
      </div>
    </div>
  </div>

<br><br>
<!-------------------------------------------------------------------- Details and Footers --------------------------------------------->
<!---
</br>
</br>


<div class="container">
    </br>
</br>
    <footer class="footer">
        <div class="container">
            <div class="row"> 
            <div class="col-sm-4 col-sm-6">
                    <h5><a class="navbar-brand" href="index_signedin.php"><span><img src="img/cin_icon.jpeg" height="40px"></span><h9 style="color:#0000EF;">&nbsp;About Us</h9></a></h5>
                  </br>
                </br>
              </br>
            </br>
                    <p><b style="color:#01AFFF;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Feel More With Cineworld Cinemas</b></p>
                    <p style="color:#01AFFF;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Anywhere Anytime Service</h5>
                    <h5 style="color:#01AFFF;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Secure And Reliable Payment Facility</h5>                   
                </div>            
                <div class="col-sm-3 col-sm-6">
                </br>
                    <h5><span><h19 style="color:#0000EF;">Quick Links</h19></span></h5>
                    <ul class="list-unstyled">
                      <li><a href="index_signedin.php" style="color:#01AFFF;">Home</a></li>
                        <li><a href="contact.php"  style="color:#01AFFF;">Our Location</a></li>
                      </br>
                        <li><a href="faq.php" style="color:#01AFFF;">Support</a></li>
                        <li><a href="contact.php" style="color:#01AFFF;">Contact</a></li>
                    </ul>                    
                </div>
              </br>

                <div class="col-xs-0 col-sm-4">
                    <div class="nav navbar-nav" style="padding: 40px 10px;" style="color:#0000EF;">
                        <a style="color:#0000EF;" class="btn btn-social-icon btn-google-plus" href="http://plus.google.com"><i class="fa fa-google-plus fa-2x"></i></a>
                        <a style="color:#0000EF;" class="btn btn-social-icon btn-facebook" href="http://www.facebook.com"><i class="fa fa-facebook fa-2x"></i></a>
                        <a style="color:#0000EF;" class="btn btn-social-icon btn-linkedin" href="http://www.linkedin.com/in/"><i class="fa fa-linkedin fa-2x"></i></a>
                        <a style="color:#0000EF;" class="btn btn-social-icon btn-twitter" href="http://twitter.com/"><i class="fa fa-twitter fa-2x"></i></a>
                        <a style="color:#0000EF;" class="btn btn-social-icon btn-youtube" href="http://youtube.com/"><i class="fa fa-youtube fa-2x"></i></a>
                        <a style="color:#0000EF;" class="btn btn-social-icon" href="mailto:contactus@cineworld.com"><i class="fa fa-envelope-o fa-2x"></i></a>
                    </div>
                </div>
                <div class="col-xs-12">
                    <p style="padding:30px;"></p>
                  </br>
                    <p align=center>Copyright © 2019 Cineworld</p>
                </div>
            </div>
        </div>
    </footer>
</div>
-->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.3.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


</body>

</html>



