<html>

<head>
    <title>User_Id_Password_Check</title>
</head>

<body>
    <?php
     include 'connection.php';
                   $recid=$_POST['userid'];
                   $recpass=$_POST['pass'];
                   
            $sql = "SELECT password FROM login where email='$recid'";
            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
             // output data of each row
             while($row = $result->fetch_assoc()) {
               $pass=$row["password"];
                             }
                } else {
                echo "<script type='text/javascript'> { alert('No entries found with this email.');} window.location.replace('Customer_login.php');</script>";
            }
    
                
            if(strcmp($recpass,$pass)==0)
            {
                 session_start();
                    $_SESSION['user_id'] = $recid;
                 echo "<script type='text/javascript'>  window.location.replace('index_signedin.php');</script>";
            }
            else{
                
                    //header("Refresh:0; URL=Customer_login.php");
                     echo "<script type='text/javascript'> { alert('Incorrect Password.');} window.location.replace('Customer_login.php');</script>";
                       die();
            }
            
                $conn->close();
            // Check connection

            
        ?>
</body>

</html>
