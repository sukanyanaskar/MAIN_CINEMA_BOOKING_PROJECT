<html>
<title>payment_gateway</title>

<head>
    <?php
    session_start();
if ( isset( $_SESSION['user_id'] ) ) {
    $idh=$_SESSION['user_id'];
    
} else {echo 'session expired.';
    header("Refresh:0; URL=expiredsess.php");
    die();
}
    $crdnum=$_POST['cardNumber'];
    ?>
    <link rel="stylesheet" href="5.css" />

</head>

<body>
    <table id="bank_transac">
        <tr>
            <td id="bankname">BANK</td>
        </tr>
        <tr>
            <td>
                <div>
                    <pre id="transac_details">Merchant                           : CineWorld<br>Debit Card                         : <?php echo $crdnum ?></pre>

                </div>
        <tr>
        <tr>
            <td>
                
                    <?php ?>
                    <a href="saveBooking.php"><button style="margin-left:110px"> Make Payment</button></a>
                <br><br>
                <font size="3"><a href="payment.php">Go Back </a>to merchant</font>

            </td>
        </tr>
        </tr>
        </td>
        </tr>
    </table>
</body>

</html>
