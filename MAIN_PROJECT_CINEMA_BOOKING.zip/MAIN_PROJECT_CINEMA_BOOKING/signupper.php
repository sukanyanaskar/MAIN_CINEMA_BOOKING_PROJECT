<html>

<head>
    <title>New_User_Signup</title>
</head>

<body>
    <?php
     include 'connection.php';

                $name=$_POST['name'];
                $phone=$_POST['phone'];
                $email=$_POST['email'];
                $password=$_POST['password'];


$sql = "INSERT INTO login (name,email,phone_no,password) VALUES ('$name', '$email', $phone, '$password')";


if ($conn->query($sql) === TRUE) {
    echo'<script>alert("Signed Up Successfully!!");window.location.replace("index_signedin.php");</script>';
    
  
} else {
    echo "<script type='text/javascript'> { alert('Problem Signing Up. Try Again.');} window.location.replace('Customer_login.php');</script>";
            }


                $conn->close();
            // Check connection

            
        ?>
</body>

</html>





