<html>

<head>
    <title>SIGN IN FIRST </title>
</head>

<body>
    <?php
     echo "<script type='text/javascript'> { alert('Sorry for the inconvenience.You have to SIGN IN first to see further details');} window.location.replace('index.php');</script>";
        ?>
</body>

</html>
